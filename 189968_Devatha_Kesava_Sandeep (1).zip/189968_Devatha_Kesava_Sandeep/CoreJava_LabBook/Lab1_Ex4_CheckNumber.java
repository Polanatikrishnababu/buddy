package capgemini.labbook;

public class Lab1_Ex4_CheckNumber {
	
	public static boolean checkNumber (int num) {
		boolean result;
		int a = 2;
		while(a<num){
			a*=2;
		}
		if(a==num) result = true;
		else result = false;
		return result;
	}
	
	public static void main(String[] args) {
		int n = 15;
		boolean x;
		x = checkNumber(n);
		if(x){
			System.out.println("The given number is power of 2");
		}
		else{
			System.out.println("The given number is not a power of 2");
		}
	}
}
