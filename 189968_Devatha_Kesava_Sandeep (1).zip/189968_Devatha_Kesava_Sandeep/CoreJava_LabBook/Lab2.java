package capgemini.labbook;

import java.util.Scanner;

abstract class Item {
	private int idNo;
	private String title;
	private int no_ofcopies;

	Item() {
		System.out.println("Default->constructor");
	}

	public int getIdNo() {
		return idNo;
	}

	public void setIdNo(int idNo) {
		this.idNo = idNo;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getNo_ofcopies() {
		return no_ofcopies;
	}

	public void setNo_ofcopies(int no_ofcopies) {
		this.no_ofcopies = no_ofcopies;
	}

	@Override
	public String toString() {
		return super.toString();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}

abstract class WrittenItem extends Item {
	private String author;

	WrittenItem() {
		System.out.println("WrittenItem->def");
	}

	@Override
	public String toString() {
		return super.toString();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}

class Book extends WrittenItem {

	Book() {
		super();
		System.out.println("Book->def");
	}
}

class JournalPaper extends WrittenItem {
	private int year;
}

abstract class MediaItem extends Item {

	MediaItem() {
		System.out.println("MediaItem->def");
	}

	@Override
	public String toString() {
		return super.toString();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

}

class Video extends MediaItem {

	private String director;
	private String genre;
	private int year_released;

	@Override
	public String toString() {
		return super.toString();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}

class Cd extends MediaItem {
	private String artist;
	private String genre;
}

class Lab2 extends Item {
	private Object idNo;

	public Lab2() {
		super();
		System.out.println("Library->def");
	}

	public Lab2(int idNo, String title, int no_ofcopies) {
		this.setIdNo(idNo);
		this.setTitle(title);
		this.setNo_ofcopies(no_ofcopies);

	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		return true;
	}

	public static void main(String[] args) {
		Lab2 lib1 = new Lab2();
		Lab2 lib2 = new Lab2(23, "Java", 3);
		System.out.println(lib1.toString());
		if (lib1.equals(lib2)) {
			System.out.println("both are equal");
		} else {
			System.out.println("NOT equal");
		}
	}
}