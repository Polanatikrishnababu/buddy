package capgemini.labbook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class Lab8_Ex2_FileLineNumbers {

	public static void main(String[] args) {

		File file = new File("C:\\kesava\\FileLineNumbers.txt");

		try (FileReader fileReader = new FileReader(file);
				LineNumberReader lineReader = new LineNumberReader(fileReader);) {

			lineReader.setLineNumber(0);
			String line = lineReader.readLine();
			while (line != null) {
				System.out.println(lineReader.getLineNumber() + " " + line);
				line = lineReader.readLine();
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
