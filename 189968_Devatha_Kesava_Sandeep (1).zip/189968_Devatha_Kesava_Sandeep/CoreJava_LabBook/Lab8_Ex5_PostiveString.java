package capgemini.labbook;

import java.util.Scanner;

public class Lab8_Ex5_PostiveString {
	public static boolean isPositive(String string) {
		string = string.toLowerCase();
		for (int i = 0; i < string.length() - 1; i++)
			if (string.charAt(i) > string.charAt(i + 1))
				return false;
		return true;

	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a String");
		String s = scanner.next();
		System.out.println(isPositive(s) ? "String is Postive" : "String is not positive");

		scanner.close();
	}
}