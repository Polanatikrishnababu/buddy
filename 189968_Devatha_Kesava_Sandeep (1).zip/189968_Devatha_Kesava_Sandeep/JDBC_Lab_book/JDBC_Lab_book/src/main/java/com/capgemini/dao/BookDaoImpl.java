package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.bean.Author;
import com.capgemini.bean.Book;
import com.capgemini.utility.DBConnection;

public class BookDaoImpl implements BookDao{
	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet resultSet=null;
	int row=-1;
	public int insertToBook(Book book) {
		int authorId=0;
		int isbn=0;
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select isbnseq.NEXTVAL from dual");
			resultSet=statement.executeQuery();
			while(resultSet.next())
				isbn=resultSet.getInt(1);
			statement=connection.prepareStatement("select authorIdseq.NEXTVAL from dual");
			resultSet=statement.executeQuery();
			while(resultSet.next())
				authorId=resultSet.getInt(1);
			statement=connection.prepareStatement("insert into book values(?,?,?,?)");
			statement.setInt(1, isbn);
			statement.setString(2, book.getTitle());
			statement.setInt(3, authorId);
			statement.setInt(4, book.getPrice());
			row=statement.executeUpdate();
			System.out.println("Book inserted");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return authorId;
	}
	@Override
	public void insertToAuthor(Author author) {
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("insert into author values(?,?)");
			statement.setInt(1, author.getAuthorId());
			statement.setString(2, author.getName());
			row=statement.executeUpdate();
			System.out.println("Author inserted");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	public Book getBookDetails(String name) {
		int authorId=0;
		Book book=null;
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select authorId from author where name=?");
			statement.setString(1, name);
			resultSet=statement.executeQuery();
			while(resultSet.next())
				authorId=resultSet.getInt("authorId");
			//System.out.println(authorId);
			statement=connection.prepareStatement("select * from book where authorId=?");
			statement.setInt(1,authorId);
			resultSet=statement.executeQuery();
			if(resultSet.next()) {
				book=new Book();
				book.setIsbn(resultSet.getInt("isbn"));
				book.setTitle(resultSet.getString("title"));
				book.setAuthorId(resultSet.getInt("authorId"));
				book.setPrice(resultSet.getInt("price"));
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return book;
	}
	public void updatePrice(String name,int amount) {
		int authorId=0;
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select authorId from author where name=?");
			statement.setString(1, name);
			resultSet=statement.executeQuery();
			while(resultSet.next())
				authorId=resultSet.getInt("authorId");
			//System.out.println(authorId);
			statement=connection.prepareStatement("update book set price=? where authorId=?");
			statement.setInt(1,amount);
			statement.setInt(2, authorId);
			row=statement.executeUpdate();
			System.out.println("updated successfully "+row);	
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
	}

}
