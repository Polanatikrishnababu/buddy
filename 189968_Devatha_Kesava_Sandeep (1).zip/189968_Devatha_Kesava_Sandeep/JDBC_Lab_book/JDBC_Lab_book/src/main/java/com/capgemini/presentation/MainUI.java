package com.capgemini.presentation;

import java.util.Scanner;

import com.capgemini.bean.Author;
import com.capgemini.bean.Book;
import com.capgemini.service.BookService;
import com.capgemini.service.BookServiceImpl;

public class MainUI {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		BookService service=new BookServiceImpl();
		int authorId=0;
		while(true) {
			System.out.println("1) insert\n 2)get book details\n 3)update price");
			System.out.println("Enter your choice:");
			int choice=scanner.nextInt();
			switch(choice) {
			case 1: {
				scanner.nextLine();
				System.out.println("Enter title of the book:");
				String title=scanner.nextLine();
				System.out.println("Enter price:");
				int price=scanner.nextInt();
				scanner.nextLine();
				System.out.println("Enter author name:");
				String name=scanner.nextLine();
				Book book=new Book(0,title,0,price);
				authorId=service.insertToBook(book);
				Author author=new Author(authorId,name);
				service.insertToAuthor(author);
			}break;
			case 2: {
				scanner.nextLine();
				System.out.println("Enter author name you want:");
				String name=scanner.nextLine();
				Book book=service.getBookDetails(name);
				System.out.println(book);
			}break;
			case 3:{
				scanner.nextLine();
				System.out.println("Enter author name you want:");
				String name=scanner.nextLine();
				System.out.println("Enter the price you want to update to:");
				int amount=scanner.nextInt();
				service.updatePrice(name,amount);
			}break;
			}
			
		}
	}
}
